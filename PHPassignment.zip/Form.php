<!DOCTYPE HTML>
<html>
<head>

<font face="khaki" color=""><h1>Eppy Bakery</h1></font>
<h5><em>"Precise Knowledge in Baking"</em></h5><br>
<body>
<div id="container">
	
	<header role="banner" id="main-header">
		<div id="bakery">
			<img id="bakery" src="bakery.jpg" height="300px" width="1300px">
		</div>
		
		<nav id="main_nav">
			<ul>
				<li><a href="index.html">Home</a></li>
				<li><a href="about_us.html">About Us</a></li>
				<li><a href="contacts.html">Contacts</a></li>
			</ul>
		</nav>
	</header>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css"/>
<title>
</title>
<style> 
</style>
</head>

	

	
	

		<h4><em>Create User Account</em><h4/>
		<form action="proceed.php" method="post">
	<form name="Ashler" onsubmit="validateForm()">
  <div class="form-group">
    <label for="exampleInputFirstName"></label>
    <input type="Name" class="form-control" name="Name" id="exampleInputFirstName" required placeholder="Name">
  </div>
  <div class="form-group">
    <label for="exampleInputSurname"></label>
    <input type="Surname" class="form-control" name="Surname" id="exampleInputSurname" required placeholder="Surname">
  </div>
  <div class="form-group">
    <label for="exampleInput PhysicalAddress"></label>
    <input type=" Physical Address" class="form-control" name="Physical Address" id="exampleInputPhysical Address" required placeholder="Physical Address">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail_Address"></label>
    <input type="Email Address" class="form-control" name="Email Address" id="exampleInputEmail Address"required placeholder="Email Address">
  </div>
  <div class="form-group">
    <label for="exampleInputTelephone"></label>
    <input type="Telephone" class="form-control" name="Telephone" id="exampleInputTelephone"required placeholder="Telephone">
  </div>
  
  <label for="sel1">Date of Birth</label>
  
  <select name="DOBMonth">
	<option> - Month - </option>
	<option value="January">January</option>
	<option value="Febuary">Febuary</option>
	<option value="March">March</option>
	<option value="April">April</option>
	<option value="May">May</option>
	<option value="June">June</option>
	<option value="July">July</option>
	<option value="August">August</option>
	<option value="September">September</option>
	<option value="October">October</option>
	<option value="November">November</option>
	<option value="December">December</option>
</select>

<select name="DOBDay">
	<option> - Day - </option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
	<option value="24">24</option>
	<option value="25">25</option>
	<option value="26">26</option>
	<option value="27">27</option>
	<option value="28">28</option>
	<option value="29">29</option>
	<option value="30">30</option>
	<option value="31">31</option>
</select>

<select name="DOBYear">
	<option> - Year - </option>
	<option value="1993">1993</option>
	<option value="1992">1992</option>
	<option value="1991">1991</option>
	<option value="1990">1990</option>
	<option value="1989">1989</option>
	<option value="1988">1988</option>
	<option value="1987">1987</option>
	<option value="1986">1986</option>
	<option value="1985">1985</option>
	<option value="1984">1984</option>
	<option value="1983">1983</option>
	<option value="1982">1982</option>
	<option value="1981">1981</option>
	<option value="1980">1980</option>
	<option value="1979">1979</option>
	<option value="1978">1978</option>
	<option value="1977">1977</option>
	<option value="1976">1976</option>
	<option value="1975">1975</option>
	<option value="1974">1974</option>
	<option value="1973">1973</option>
	<option value="1972">1972</option>
	<option value="1971">1971</option>
	<option value="1970">1970</option>
	<option value="1969">1969</option>
	<option value="1968">1968</option>
	<option value="1967">1967</option>
	<option value="1966">1966</option>
	<option value="1965">1965</option>
	<option value="1964">1964</option>
	<option value="1963">1963</option>
	<option value="1962">1962</option>
	<option value="1961">1961</option>
	<option value="1960">1960</option>
	<option value="1959">1959</option>
	<option value="1958">1958</option>
	<option value="1957">1957</option>
	<option value="1956">1956</option>
	<option value="1955">1955</option>
	<option value="1954">1954</option>
	<option value="1953">1953</option>
	<option value="1952">1952</option>
	<option value="1951">1951</option>
	<option value="1950">1950</option>
	<option value="1949">1949</option>
	<option value="1948">1948</option>
	<option value="1947">1947</option><br>
	 <input type="Date of Birth" class="form-control" name="Date of Birth" id="exampleInputDate of Birth"required placeholder="Date of Birth">
	
</select><br>

 <div class="form-group">
  <label for="sel1">Choose Gender</label><br>
    <input type="radio" name="Choose Gender" value="male" checked> Male<br>
  <input type="radio" name="Choose Gender" value="female"> Female<br>
  </div> 
				
<div class="form-group">
    <label for="exampleInputPosition"></label>
    <input type="Position" class="form-control" name="Position" id="exampleInputPosition" required placeholder="Position">
  </div>
  
 <div class="form-group">
    <label for="exampleInputBranch"></label>
    <input type="Branch" class="form-control" name="Branch" id="exampleInputBranch"required placeholder="Branch">
  </div>
			
<div class="form-group">
  <label for="sel1">Employment Status</label><br>
    <input type="radio" name="Employment Status" value="Contract " checked> Contract <br>
  <input type="radio" name="Employment Status" value="Permanent"> Permanent<br>
  </div> 			
			
<div class="form-group">
    <label for="exampleInputCity"></label>
    <input type="City" class="form-control" name="City" id="exampleInputCity"required placeholder="City">
  </div>
						
<div class="form-group">
	 <label for="sel1">Select Country Please</label><br>
  </div>	
<select>
                      <option value="Botswana">Botswana</option>
                      <option value="South Africa">South Africa</option>
					  <option value="Zambia">Zambia</option>
                      <option value="Zimbabwe">Zimbabwe</option>
					   <input type="Select Country Please" class="form-control" name="Select Country Please" id="exampleInputSelect Country Please"required placeholder="Select Country Please">
</select>	
			
<div class="form-group">
    <label for="exampleInputEmployee Number"></label>
    <input type="Employee Number" class="form-control" name="Employee Number" id="exampleInputEmployee Number" required placeholder="Employee Number">
  </div>			
			
<div class="form-group">
    <label for="exampleInputDate"></label>
    <input type="Date" class="form-control" name="Date" id="exampleInputDate"required placeholder="Date">
  </div>			

  
<div class="form-actions">

  <button type="submit" class="btn btn-primary">Save changes</button>
  <button type="button" class="btn">Cancel</button>
</div>
<br>

<p>
  <button class="btn btn-large btn-primary" type="button">Submit</button>
 
</p>
<br>
						
</form>
		</fieldset>
	</form>
<script src="http://maxcdn.bootstraprapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"> </script>	
<script type="text/javascript" src="validation.js"></script>

</body>
</html>