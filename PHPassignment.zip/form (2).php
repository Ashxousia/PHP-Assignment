<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="css/style.css"/>
</head>
<body>
	<form action="logged.php" method="post">
	<label for="username">Username:</label>
	<input type="text" name="username"></input>
	
	<label for="password">Password:</label>
	<input type="password" name="password"></input>
	
	<input type="submit" value="Login"></input>	
	</form>
</html>