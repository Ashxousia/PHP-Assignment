<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<?php
	$username=$_POST['username'];
	$password=$_POST['password'];
		
	if($_POST['username']=='cuthbert' && $_POST['password']=='1234'){
	?>
			<a href="profile.php" username=<?php echo $_POST['username']?>">
			Go to profile Page
			</a>
		<?php 
		}
		else{
		?>
		<a href="index.php">Log in failure go to home</a>
		<?php
		}
	?>
	
</html>